<?php

namespace App\Models;

use MongoDB\Laravel\Auth\User as Authenticatable;
use MongoDB\Laravel\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class User extends Authenticatable
{
    use SoftDeletes;

    protected $collection = 'users';

    protected $fillable = [
        'name', 'email', 'password', 'key', 'username', 'display_name', 'first_name', 'last_name', 'address_book_id', 'status'
    ];

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->key)) {
                $model->key = (string) Str::uuid();
            }
            if ($model->first_name) { $model->first_name = strtolower($model->first_name); }
            if ($model->last_name) { $model->last_name = strtolower($model->last_name); }
            if ($model->name) { $model->name = strtolower($model->name); }
            if ($model->email) { $model->email = strtolower($model->email); }
        });

        static::updating(function ($model) {
            if ($model->first_name) { $model->first_name = strtolower($model->first_name); }
            if ($model->last_name) { $model->last_name = strtolower($model->last_name); }
            if ($model->name) { $model->name = strtolower($model->name); }
            if ($model->email) { $model->email = strtolower($model->email); }
        });
    }

    public function addressBook()
    {
        return $this->belongsTo(AddressBook::class);
    }
}
